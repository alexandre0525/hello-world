<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Mon Site de Recettes</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
<header>
    <h1>Mon Site de Recettes</h1>
    <nav>
        <ul>
            <li><a href="index.php">Accueil</a></li>
            <li><a href="recipes.php">Recettes</a></li>
            <li><a href="contact.php">Contactez-nous !</a></li>
            <li><a href="+.php">+</a></li>
        </ul>
    </nav>
</header>
<main>