<?php
include 'templates/header.php';
?>

<h1>Milles excuses !</h1>

<img src="https://tse2.mm.bing.net/th?id=OIP.5EWqQEyGSLTX_0aI9JhxvwHaFt&pid=Api&P=0&h=180">
<ul>
    <li>Comme tu as dû surement être mis au courant, il y a un problème de création de la base de données SQL sur Windows qui n'est pas fonctionnelle.</li>
    <li>Nous avons donc rajouter quelques fonctionnalités pour se faire pardonner dont un formulaire de contact et quelques liens externes pour des chaines de recettes de cuisines.</li>
    <li>N'ayant donc pas de base de données pour l'ajout de nouvelles recettes, l'option d'ajout n'a que la forme.</li>
    <li>Et pour le retard bon pas d'excuses évidemment...</li>
</ul>
<h5>Étant donné que j'ai pas grand chose pour me faire pardonner je te laisse apprécier cette magnifique vidéo !</h5>
<a href="https://youtu.be/ZnnG2zdWUHE?si=tbTHaRztwIf6fNDm">Clique ici !</a>

<li>J'en profite ici également pour dire que si l'on a choisi cette <a href="https://www.youtube.com/@SaborIntenso">chaine Youtube</a> c'est parce qu'elle est déjà connue pour ces recettes mythiques au Portugal.</li>
<li>A titre d'exemple elle fonctionne plutôt bien du coup.</li>
<?php
include 'templates/footer.php';
?>
