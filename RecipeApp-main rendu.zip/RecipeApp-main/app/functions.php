<?php

function getAllRecipes()
{
    $recipes = [];
    $files = glob('./data/recettes/*.json');

    foreach ($files as $file) {
        $content = file_get_contents($file);
        $recipe = json_decode($content, true);
        array_push($recipes, $recipe);
    }

    return $recipes;
}


function readRecipe($id)
{
    $currentDir = getcwd();
    $filePath = $currentDir . '/data/recettes/' . $id . '.json';

    if (file_exists($filePath)) {
        $content = file_get_contents($filePath);
        $recipeDetails = json_decode($content, true);
        return $recipeDetails;
    }

    else {
        return [];
    }
}
