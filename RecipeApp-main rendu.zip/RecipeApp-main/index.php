<?php
// 👩‍💻 Incluez le header
include 'templates/header.php';
?>

<h1>Hello there!</h1>

<p>Bienvenue sur mon super site de recettes, on va bien manger comme chez mamie !</p>

<img src="https://st.depositphotos.com/1570716/1697/i/950/depositphotos_16978587-stock-photo-male-chef-cooking.jpg" alt="">

<div>
    <a href="recipes.php">Par ici les recettes!</a>
</div>

<?php
// 👩‍💻 Incluez le footer
include 'templates/footer.php'
?>
